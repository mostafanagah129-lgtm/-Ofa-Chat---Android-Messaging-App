ملف بناء Ofa Chat على GitHub Actions

المسار المطلوب داخل مستودع GitHub:
.github/workflows/android.yml

هذا الـ workflow يفك ملف Ofa_Chat_Android_Starter_v2.zip الموجود في جذر المستودع، ثم يبني APK ويرفعه كـ Artifact.

قبل تشغيله يجب إنشاء تطبيق Firebase Android بمعرّف الحزمة com.ofachat.app، وتفعيل Authentication > Phone، ثم وضع ملف google-services.json داخل مجلد app/ في المشروع. لا تشارك مفاتيح أو كلمات مرور. ملف إعداد Firebase للعميل ليس بديلاً عن قواعد Firestore/Storage الآمنة.

بعد نجاح البناء: GitHub > Actions > اختر Build Ofa Chat APK > آخر تشغيل ناجح > Artifacts > OfaChat-debug-apk.

تنبيه: هذا يبني نسخة Debug أولية. التطبيق الحالي يحتوي على شاشة التحقق بالهاتف فقط؛ المحادثات الفعلية والمجموعات والمكالمات لم تُنفذ بعد.
