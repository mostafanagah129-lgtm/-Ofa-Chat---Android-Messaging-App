# Ofa Chat — full-stack foundation

This repository is an initial self-hosted foundation, not a finished production messenger.

## Contents
- `android/`: existing Jetpack Compose Android starter UI.
- `backend/`: Node.js REST API + Socket.IO realtime messaging/signaling scaffold.
- `Dockerfile`, `docker-compose.yml`: self-hosted API deployment scaffold.
- `.github/workflows/build.yml`: GitHub Actions Android APK build workflow.

## Important limitations before real-world use
- Backend data is currently in memory and is lost when the server restarts. PostgreSQL persistence, migrations, backups, rate limiting, moderation/abuse controls, and production monitoring must be added before launch.
- Registration uses phone number plus password. It does not verify phone ownership. Do not use phone-only sign-in as secure authentication.
- Google, Facebook, and Apple OAuth are not configured; each requires provider registration and secure server-side configuration.
- Stories currently support text only; media upload/storage is not implemented.
- Call signaling scaffold is present, but the Android WebRTC client and TURN server are not implemented. Calls are not yet usable.
- Android screens are still a starter UI and are not yet connected to this backend.

## Build Android APK
GitHub Actions runs the workflow `Build Ofa Chat APK`. Download the `OfaChat-debug-apk` artifact from a successful run.

## Run backend locally or on a server
1. Copy `backend/.env.example` to `backend/.env` and set a random `JWT_SECRET` of at least 32 characters.
2. In `backend/`, run `npm install` then `npm start` with Node.js 20+.
3. Check `GET /health`.

For Docker, set `JWT_SECRET` in the environment and run `docker compose up --build -d`.
