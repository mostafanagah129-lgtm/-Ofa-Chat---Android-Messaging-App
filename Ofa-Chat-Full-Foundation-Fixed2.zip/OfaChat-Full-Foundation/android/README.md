# Ofa Chat — Android starter

Fresh Jetpack Compose starter for Ofa Chat.

Included: dark home UI and preview navigation for Home, Chats, Stories, Calls, and Profile.

Not connected yet: authentication, phone-number account lookup, messaging, 24-hour story expiry, voice/video calls, and server storage.

Build with Android Studio, JDK 17, and Android SDK 35.
