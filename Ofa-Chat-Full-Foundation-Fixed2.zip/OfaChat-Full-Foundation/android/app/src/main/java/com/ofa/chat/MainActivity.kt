package com.ofa.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF071116)
private val Panel = Color(0xFF10232B)
private val Mint = Color(0xFF65E6D0)
private val Muted = Color(0xFF91A8AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OfaApp() }
    }
}

@Composable
fun OfaApp() {
    var page by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF102B32), Night, Color(0xFF05090D)))
            )
        ) {
            Row(Modifier.fillMaxWidth().padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("𝕺𝖋𝖆 𝖈𝖍𝖆𝖙", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Stay close. Feel connected.", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.NotificationsNone, null, tint = Mint, modifier = Modifier.size(26.dp))
            }
            Box(Modifier.weight(1f)) {
                when (page) {
                    "Home" -> HomeScreen()
                    "Stories" -> PreviewScreen("Stories", "Your moments will appear here")
                    "Calls" -> PreviewScreen("Calls", "Your recent calls will appear here")
                    "Profile" -> PreviewScreen("Profile", "Your profile preview")
                    else -> PreviewScreen("Chats", "Your conversations will appear here")
                }
            }
            NavigationBar(containerColor = Color(0xDD09171D)) {
                listOf(
                    "Home" to Icons.Default.Home,
                    "Chats" to Icons.Default.ChatBubbleOutline,
                    "Stories" to Icons.Default.Circle,
                    "Calls" to Icons.Default.Call,
                    "Profile" to Icons.Default.Person
                ).forEach { (label, icon) ->
                    NavigationBarItem(
                        selected = page == label, onClick = { page = label },
                        icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Mint, selectedTextColor = Mint,
                            indicatorColor = Color(0xFF1B3A40),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen() {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC17343B)),
            shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("WELCOME BACK", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Every moment,\none connection.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("A calmer space for your conversations.", color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("STORIES", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("Your story", "Mona", "Omar", "Salma").forEachIndexed { i, name ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(58.dp).background(
                        if (i == 0) Brush.linearGradient(listOf(Panel, Panel)) else Brush.linearGradient(listOf(Mint, Color(0xFF397B91))),
                        CircleShape
                    ), contentAlignment = Alignment.Center) {
                        if (i == 0) Icon(Icons.Default.Add, null, tint = Mint)
                        else Text(name.take(1), color = Night, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(name, color = Muted, fontSize = 10.sp)
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        Text("MESSAGES", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        listOf("Mona Hassan", "Omar Ali", "Salma Ahmed").forEach { name ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp)
                .background(Panel, RoundedCornerShape(18.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF24464D), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text(name.first().toString(), color = Mint, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Start a new conversation", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}

@Composable
private fun PreviewScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Muted)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Text("Preview screen — features are not connected yet.", color = Muted,
                modifier = Modifier.padding(18.dp))
        }
    }
}
