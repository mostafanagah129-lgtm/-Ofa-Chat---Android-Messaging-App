require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || '*', methods: ['GET', 'POST'] } });
const PORT = Number(process.env.PORT || 8080);
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) {
  console.error('JWT_SECRET must be set to a random secret of at least 32 characters.');
  process.exit(1);
}

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));

// In-memory development store only. Replace with PostgreSQL before production.
const users = new Map();
const messages = new Map();
const stories = new Map();
const online = new Map();

function tokenFor(user) {
  return jwt.sign({ sub: user.id, phone: user.phone }, SECRET, { expiresIn: '7d' });
}
function auth(req, res, next) {
  const raw = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try {
    const payload = jwt.verify(raw, SECRET);
    const user = users.get(payload.sub);
    if (!user) return res.status(401).json({ error: 'account_not_found' });
    req.user = user;
    next();
  } catch { return res.status(401).json({ error: 'invalid_or_expired_token' }); }
}
function publicUser(user) { return { id: user.id, displayName: user.displayName, phone: user.phone }; }

app.get('/health', (_req, res) => res.json({ ok: true, service: 'ofa-chat-backend', mode: 'development-memory-store' }));

// Phone + password is used here; phone-only login without verification is not secure.
app.post('/v1/auth/register', async (req, res) => {
  const { phone, password, displayName } = req.body || {};
  if (typeof phone !== 'string' || !/^\+[1-9]\d{7,14}$/.test(phone)) return res.status(400).json({ error: 'phone_must_be_E164' });
  if (typeof password !== 'string' || password.length < 10) return res.status(400).json({ error: 'password_minimum_10_characters' });
  if (typeof displayName !== 'string' || displayName.trim().length < 2) return res.status(400).json({ error: 'display_name_required' });
  if ([...users.values()].some(u => u.phone === phone)) return res.status(409).json({ error: 'phone_already_registered' });
  const user = { id: cryptoRandomId(), phone, displayName: displayName.trim().slice(0, 50), passwordHash: await bcrypt.hash(password, 12) };
  users.set(user.id, user);
  res.status(201).json({ token: tokenFor(user), user: publicUser(user) });
});
app.post('/v1/auth/login', async (req, res) => {
  const { phone, password } = req.body || {};
  const user = [...users.values()].find(u => u.phone === phone);
  if (!user || typeof password !== 'string' || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: 'invalid_credentials' });
  res.json({ token: tokenFor(user), user: publicUser(user) });
});
app.get('/v1/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
app.get('/v1/users/lookup', auth, (req, res) => {
  const phone = String(req.query.phone || '');
  const found = [...users.values()].find(u => u.phone === phone && u.id !== req.user.id);
  res.json({ user: found ? publicUser(found) : null });
});
app.get('/v1/messages/:userId', auth, (req, res) => {
  const key = conversationKey(req.user.id, req.params.userId);
  res.json({ messages: messages.get(key) || [] });
});
app.post('/v1/stories', auth, (req, res) => {
  const { text } = req.body || {};
  if (typeof text !== 'string' || !text.trim()) return res.status(400).json({ error: 'story_text_required' });
  const story = { id: cryptoRandomId(), userId: req.user.id, text: text.trim().slice(0, 500), createdAt: Date.now(), expiresAt: Date.now() + 24 * 60 * 60 * 1000 };
  stories.set(story.id, story);
  res.status(201).json({ story });
});
app.get('/v1/stories', auth, (_req, res) => {
  const now = Date.now();
  for (const [id, story] of stories) if (story.expiresAt <= now) stories.delete(id);
  res.json({ stories: [...stories.values()] });
});

io.use((socket, next) => {
  try {
    const payload = jwt.verify(socket.handshake.auth?.token || '', SECRET);
    if (!users.has(payload.sub)) return next(new Error('unauthorized'));
    socket.userId = payload.sub;
    next();
  } catch { next(new Error('unauthorized')); }
});
io.on('connection', socket => {
  online.set(socket.userId, socket.id);
  socket.join(`user:${socket.userId}`);
  socket.on('message:send', ({ to, text }) => {
    if (typeof to !== 'string' || typeof text !== 'string' || !text.trim() || text.length > 4000) return;
    const recipient = users.get(to);
    if (!recipient) return;
    const item = { id: cryptoRandomId(), from: socket.userId, to, text: text.trim(), createdAt: Date.now() };
    const key = conversationKey(socket.userId, to);
    const list = messages.get(key) || [];
    list.push(item); messages.set(key, list);
    io.to(`user:${to}`).emit('message:new', item);
    socket.emit('message:sent', item);
  });
  // WebRTC signaling only. Media travels peer-to-peer; TURN infrastructure is still required for reliable NAT traversal.
  socket.on('call:signal', ({ to, signal }) => {
    if (typeof to === 'string' && users.has(to)) io.to(`user:${to}`).emit('call:signal', { from: socket.userId, signal });
  });
  socket.on('disconnect', () => { if (online.get(socket.userId) === socket.id) online.delete(socket.userId); });
});

function conversationKey(a, b) { return [a, b].sort().join(':'); }
function cryptoRandomId() { return require('crypto').randomUUID(); }
server.listen(PORT, '0.0.0.0', () => console.log(`Ofa Chat API listening on ${PORT}`));
