# Ofa Chat — working MVP foundation

This package replaces the previous demo scaffold with a persistent backend and an Android client that can register/login, find users by phone, send messages, read conversations, and publish/read 24-hour text stories.

## Architecture
- Android: Jetpack Compose, talks to the backend over HTTPS.
- Backend: Node.js + Express + Socket.IO.
- Database: PostgreSQL (persistent; no Firebase/Supabase/Twilio).
- Docker Compose runs API + PostgreSQL locally.

## Run backend
1. Copy `backend/.env.example` to `backend/.env` and set a long random `JWT_SECRET`.
2. `docker compose up --build`
3. API health: `http://localhost:8080/health`

For a phone outside your local Wi-Fi, deploy the backend to a host with persistent PostgreSQL and HTTPS. Set the server URL in the app's connection screen. Do not expose a local development server to the public internet.

## Android build
The supplied GitHub Actions workflow keeps the same Java/Gradle build pattern and builds `android/` directly. APK output is uploaded as an Actions artifact.

## Android connection
On the app's first screen, enter the backend base URL, for example `https://your-api-domain.example` (no trailing slash). `http://10.0.2.2:8080` is only for the Android emulator talking to a backend on the same computer. A physical phone needs a reachable HTTPS URL.

## Implemented in this MVP
- Phone + password account registration/login (password is required; phone-only login is unsafe).
- JWT-authenticated API.
- Persistent users, messages and stories in PostgreSQL.
- User lookup by exact international phone number.
- Direct text messaging and conversation history.
- Stories expire after 24 hours.
- Socket.IO event broadcast for new messages.

## Not yet implemented / must not be represented as complete
- Google/Facebook/Apple OAuth provider setup.
- Image/file uploads and storage.
- WebRTC audio/video media, TURN deployment, call UI.
- Push notifications, end-to-end encryption, moderation and production security review.

This is a functional MVP milestone, not a finished public messaging product. Test with two separate accounts and a deployed HTTPS backend before real use.
