package com.ofa.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Night=Color(0xFF071116)
private val Panel=Color(0xFF10232B)
private val Mint=Color(0xFF65E6D0)
private val Muted=Color(0xFF91A8AE)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{ OfaApp() }}
}
data class ChatMessage(val id:String,val from:String,val text:String,val createdAt:String)

@Composable fun OfaApp(){
 var base by remember { mutableStateOf("https://your-api-domain.example") }
 var phone by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
 var token by remember { mutableStateOf("") }; var myId by remember { mutableStateOf("") }; var status by remember { mutableStateOf("Connect to your Ofa Chat server") }
 var register by remember { mutableStateOf(false) }; var lookupPhone by remember { mutableStateOf("") }; var peerId by remember { mutableStateOf("") }; var peerName by remember { mutableStateOf("") }
 var message by remember { mutableStateOf("") }; var messages by remember { mutableStateOf(listOf<ChatMessage>()) }; var story by remember { mutableStateOf("") }; var stories by remember { mutableStateOf("") }
 val scope= rememberCoroutineScope()
 MaterialTheme(colorScheme=darkColorScheme(primary=Mint,background=Night,surface=Panel)){
  Column(Modifier.fillMaxSize().background(Night).padding(18.dp)) {
   Text("𝕺𝖋𝖆 𝖈𝖍𝖆𝖙",fontSize=28.sp,fontWeight=FontWeight.Bold,color=Color.White)
   Text("Private connections, made simple",color=Muted,fontSize=12.sp)
   Spacer(Modifier.height(18.dp))
   if(token.isBlank()){
    Text("SERVER CONNECTION",color=Mint,fontWeight=FontWeight.Bold)
    Field("Backend HTTPS URL",base,{base=it},KeyboardType.Uri)
    Text("For a real phone, use your deployed HTTPS API URL.",color=Muted,fontSize=11.sp)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={register=false}){Text("Login")};OutlinedButton(onClick={register=true}){Text("Create account")}}
    if(register) Field("Display name",name,{name=it})
    Field("Phone in international format (+20...)",phone,{phone=it},KeyboardType.Phone)
    Field("Password (10+ characters)",password,{password=it},KeyboardType.Password)
    Button(onClick={scope.launch { status="Connecting…"; try {
      val body=JSONObject().put("phone",phone).put("password",password)
      val path=if(register){body.put("displayName",name);"/v1/auth/register"}else "/v1/auth/login"
      val result=api(base,path,"POST",null,body)
      token=result.getString("token"); myId=result.getJSONObject("user").getString("id")
      status="Signed in as "+result.getJSONObject("user").getString("displayName")
    }catch(e:Exception){status=e.message ?: "Connection failed"} },modifier=Modifier.fillMaxWidth()){Text(if(register)"Create account" else "Sign in")}
   }else{
    Text(status,color=Mint,fontSize=12.sp)
    Spacer(Modifier.height(10.dp))
    Text("FIND A PERSON",color=Mint,fontWeight=FontWeight.Bold)
    Field("Their full phone number (+20...)",lookupPhone,{lookupPhone=it},KeyboardType.Phone)
    Button(onClick=scope.launch { try { val r=api(base,"/v1/users/lookup?phone=${java.net.URLEncoder.encode(lookupPhone,"UTF-8")}","GET",token); val u=r.optJSONObject("user"); if(u==null){status="No account found"}else{peerId=u.getString("id");peerName=u.getString("displayName");status="Found $peerName"; val m=api(base,"/v1/messages/$peerId","GET",token);messages=parseMessages(m)} }catch(e:Exception){status=e.message?:"Lookup failed"} },modifier=Modifier.fillMaxWidth()){Text("Find user")}
    Text(status,color=Muted,fontSize=12.sp)
    if(peerId.isNotBlank()){
     Spacer(Modifier.height(10.dp));Text("CHAT WITH $peerName",color=Mint,fontWeight=FontWeight.Bold)
     LazyColumn(Modifier.weight(1f).fillMaxWidth().background(Panel,RoundedCornerShape(16.dp)).padding(10.dp)){items(messages){m->Text((if(m.from==myId)"You: " else "$peerName: ")+m.text,color=Color.White,modifier=Modifier.padding(5.dp))}}
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(message,{message=it},modifier=Modifier.weight(1f),placeholder={Text("Message")});Button(onClick=scope.launch { try { api(base,"/v1/messages","POST",token,JSONObject().put("to",peerId).put("text",message));message="";messages=parseMessages(api(base,"/v1/messages/$peerId","GET",token)) }catch(e:Exception){status=e.message?:"Send failed"} }){Text("Send")}}
    }
    Spacer(Modifier.height(12.dp));Divider(color=Muted)
    Text("24-HOUR STORIES",color=Mint,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
    Field("Write a short story",story,{story=it})
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     Button(onClick=scope.launch { try{api(base,"/v1/stories","POST",token,JSONObject().put("text",story));story="";status="Story published (expires in 24 hours)"}catch(e:Exception){status=e.message?:"Story failed"} }){Text("Publish")}
     OutlinedButton(onClick=scope.launch { try{stories=api(base,"/v1/stories","GET",token).getJSONArray("stories").toString(2)}catch(e:Exception){status=e.message?:"Load failed"} }){Text("Refresh stories")}
    }
    if(stories.isNotBlank()) Text(stories,color=Muted,fontSize=10.sp)
    TextButton(onClick={token="";myId="";peerId="";messages= emptyList()}){Text("Sign out")}
   }
  }
 }
}
@Composable private fun Field(label:String,value:String,onValue:(String)->Unit,type:KeyboardType=KeyboardType.Text){
 OutlinedTextField(value,onValue,modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=type))
}
private suspend fun api(base:String,path:String,method:String,token:String?,body:JSONObject?=null):JSONObject=withContext(Dispatchers.IO){
 val clean=base.trim().trimEnd('/'); require(clean.startsWith("https://")||clean.startsWith("http://10.0.2.2")){"Enter a valid HTTPS backend URL"}
 val c=(URL(clean+path).openConnection() as HttpURLConnection).apply{requestMethod=method;connectTimeout=15000;readTimeout=15000;setRequestProperty("Accept","application/json");token?.let{setRequestProperty("Authorization","Bearer $it")};if(body!=null){doOutput=true;setRequestProperty("Content-Type","application/json");outputStream.use{it.write(body.toString().toByteArray())}}}
 val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream
 val text=stream.bufferedReader().use{it.readText()};c.disconnect()
 val json=JSONObject(text);if(code !in 200..299) throw IllegalStateException(json.optString("error","HTTP $code"));json
}
private fun parseMessages(json:JSONObject):List<ChatMessage>{
 val a=json.getJSONArray("messages");return (0 until a.length()).map{val x=a.getJSONObject(it);ChatMessage(x.getString("id"),x.getString("from"),x.getString("text"),x.optString("createdAt"))}
}
