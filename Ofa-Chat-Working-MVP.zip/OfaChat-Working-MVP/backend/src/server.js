require('dotenv').config();
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const { Server } = require('socket.io');

const { DATABASE_URL, JWT_SECRET } = process.env;
if (!DATABASE_URL) throw new Error('DATABASE_URL is required');
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters');
const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined });
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || '*', methods: ['GET','POST'] } });
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));
app.use('/v1/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY, phone VARCHAR(16) UNIQUE NOT NULL,
      display_name VARCHAR(50) NOT NULL, password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS messages (
      id UUID PRIMARY KEY, sender_id UUID NOT NULL REFERENCES users(id),
      recipient_id UUID NOT NULL REFERENCES users(id), body VARCHAR(4000) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS messages_pair_time ON messages(sender_id, recipient_id, created_at);
    CREATE TABLE IF NOT EXISTS stories (
      id UUID PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id),
      body VARCHAR(500) NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ NOT NULL
    );
    CREATE INDEX IF NOT EXISTS stories_expiry ON stories(expires_at);
  `);
}
const publicUser = u => ({ id: u.id, phone: u.phone, displayName: u.display_name });
const sign = u => jwt.sign({ sub: u.id }, JWT_SECRET, { expiresIn: '7d' });
async function auth(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\\s+/i, '');
    const payload = jwt.verify(token, JWT_SECRET);
    const result = await pool.query('SELECT id, phone, display_name FROM users WHERE id=$1', [payload.sub]);
    if (!result.rowCount) return res.status(401).json({ error: 'account_not_found' });
    req.user = result.rows[0]; next();
  } catch { res.status(401).json({ error: 'invalid_or_expired_token' }); }
}
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);

app.get('/health', asyncRoute(async (_req,res) => {
  await pool.query('SELECT 1'); res.json({ ok:true, service:'ofa-chat-api', database:'connected' });
}));
app.post('/v1/auth/register', asyncRoute(async (req,res) => {
  const { phone, password, displayName } = req.body || {};
  if (typeof phone !== 'string' || !/^\\+[1-9]\\d{7,14}$/.test(phone)) return res.status(400).json({error:'phone_must_be_E164'});
  if (typeof password !== 'string' || password.length < 10) return res.status(400).json({error:'password_minimum_10_characters'});
  if (typeof displayName !== 'string' || displayName.trim().length < 2) return res.status(400).json({error:'display_name_required'});
  const id = crypto.randomUUID(), hash = await bcrypt.hash(password, 12);
  try {
    const q = await pool.query('INSERT INTO users(id,phone,display_name,password_hash) VALUES($1,$2,$3,$4) RETURNING id,phone,display_name', [id,phone,displayName.trim().slice(0,50),hash]);
    res.status(201).json({token:sign(q.rows[0]),user:publicUser(q.rows[0])});
  } catch(e) { if(e.code==='23505') return res.status(409).json({error:'phone_already_registered'}); throw e; }
}));
app.post('/v1/auth/login', asyncRoute(async (req,res) => {
  const {phone,password}=req.body||{};
  const q=await pool.query('SELECT * FROM users WHERE phone=$1',[phone || '']);
  if(!q.rowCount || typeof password!=='string' || !(await bcrypt.compare(password,q.rows[0].password_hash))) return res.status(401).json({error:'invalid_credentials'});
  res.json({token:sign(q.rows[0]),user:publicUser(q.rows[0])});
}));
app.get('/v1/me',auth,(req,res)=>res.json({user:publicUser(req.user)}));
app.get('/v1/users/lookup',auth,asyncRoute(async(req,res)=>{
  const phone=String(req.query.phone||'');
  const q=await pool.query('SELECT id,phone,display_name FROM users WHERE phone=$1 AND id<>$2',[phone,req.user.id]);
  res.json({user:q.rowCount?publicUser(q.rows[0]):null});
}));
app.get('/v1/messages/:userId',auth,asyncRoute(async(req,res)=>{
  const q=await pool.query(`SELECT id,sender_id AS "from",recipient_id AS "to",body AS text,
    (EXTRACT(EPOCH FROM created_at)*1000)::bigint AS "createdAt"
    FROM messages WHERE (sender_id=$1 AND recipient_id=$2) OR (sender_id=$2 AND recipient_id=$1)
    ORDER BY created_at ASC LIMIT 500`,[req.user.id,req.params.userId]);
  res.json({messages:q.rows});
}));
app.post('/v1/messages',auth,asyncRoute(async(req,res)=>{
  const {to,text}=req.body||{};
  if(typeof to!=='string'||typeof text!=='string'||!text.trim()||text.length>4000) return res.status(400).json({error:'invalid_message'});
  const target=await pool.query('SELECT id FROM users WHERE id=$1',[to]);
  if(!target.rowCount) return res.status(404).json({error:'recipient_not_found'});
  const q=await pool.query(`INSERT INTO messages(id,sender_id,recipient_id,body) VALUES($1,$2,$3,$4)
    RETURNING id,sender_id AS "from",recipient_id AS "to",body AS text,(EXTRACT(EPOCH FROM created_at)*1000)::bigint AS "createdAt"`,
    [crypto.randomUUID(),req.user.id,to,text.trim()]);
  const message=q.rows[0];
  io.to('user:'+to).emit('message:new',message);
  io.to('user:'+req.user.id).emit('message:new',message);
  res.status(201).json({message});
}));
app.post('/v1/stories',auth,asyncRoute(async(req,res)=>{
  const {text}=req.body||{};
  if(typeof text!=='string'||!text.trim()) return res.status(400).json({error:'story_text_required'});
  const q=await pool.query(`INSERT INTO stories(id,user_id,body,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL '24 hours')
    RETURNING id,user_id AS "userId",body AS text,created_at AS "createdAt",expires_at AS "expiresAt"`,
    [crypto.randomUUID(),req.user.id,text.trim().slice(0,500)]);
  res.status(201).json({story:q.rows[0]});
}));
app.get('/v1/stories',auth,asyncRoute(async(_req,res)=>{
  await pool.query('DELETE FROM stories WHERE expires_at<=NOW()');
  const q=await pool.query(`SELECT s.id,s.user_id AS "userId",u.display_name AS "displayName",s.body AS text,
    s.created_at AS "createdAt",s.expires_at AS "expiresAt" FROM stories s JOIN users u ON u.id=s.user_id
    WHERE s.expires_at>NOW() ORDER BY s.created_at DESC LIMIT 200`);
  res.json({stories:q.rows});
}));

io.use(async(socket,next)=>{
  try {
    const p=jwt.verify(socket.handshake.auth?.token||'',JWT_SECRET);
    const q=await pool.query('SELECT id FROM users WHERE id=$1',[p.sub]);
    if(!q.rowCount) return next(new Error('unauthorized'));
    socket.userId=p.sub; next();
  } catch { next(new Error('unauthorized')); }
});
io.on('connection',socket=>{socket.join('user:'+socket.userId);});
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'server_error'});});
const port=Number(process.env.PORT||8080);
initDb().then(()=>server.listen(port,'0.0.0.0',()=>console.log('Ofa API listening on '+port)))
  .catch(e=>{console.error('Database initialization failed',e);process.exit(1);});
