# Ofa Chat – Global country & language support patch

This patch adds:
- Country list generated from Android's ISO country list.
- International calling codes from Google's libphonenumber metadata.
- Country names localized to the currently selected app/device language.
- A reusable Jetpack Compose country picker.
- A language list and helper to apply a selected language.

## Add to GitHub

1. Extract this ZIP.
2. Upload `app/src/main/java/com/ofachat/app/OfaGlobalSupport.kt` into the same path in the Android project.
3. Open `app/build.gradle.kts` and add this line inside `dependencies { ... }`:

```kotlin
implementation("com.googlecode libphonenumber:libphonenumber:8.13.55")
```

Use the exact corrected Gradle coordinate below (without a space):
```kotlin
implementation("com.googlecode.libphonenumber:libphonenumber:8.13.55")
```

4. Commit the changes.

## Important: connect it to the registration screen

This patch supplies the country picker component and country data; it does not silently rewrite `MainActivity.kt`.
To use it in the phone registration screen, keep a selected country state and show `OfaCountryPicker`:

```kotlin
var selectedCountry by remember { mutableStateOf(defaultOfaCountry()) }

OfaCountryPicker(
    selectedCountry = selectedCountry,
    onCountrySelected = { selectedCountry = it }
)

// Use selectedCountry.callingCode as the prefix for the phone number.
```

For phone authentication, send Firebase the full international number (country calling code + national number), for example `+2010...`.
Do not add the calling code twice.

## Languages

`OfaGlobalSupport.languages()` returns language choices using native language names.
When a user selects one, call:
```kotlin
OfaGlobalSupport.applyLanguage(activity, chosenLocale.toLanguageTag())
```

This changes the Android locale, but actual interface text is translated only when matching Android resources exist, for example:
- `app/src/main/res/values/strings.xml` (default)
- `app/src/main/res/values-ar/strings.xml` (Arabic)
- `app/src/main/res/values-fr/strings.xml` (French)

There is no honest way to claim every screen is translated into every language until all displayed text is moved into string resources and translations are supplied. The current starter screen contains hard-coded Arabic text, so it needs a separate UI localization pass.

## Notes
- Calling-code metadata can be updated by upgrading libphonenumber.
- Some countries/territories share calling codes; this is expected.
- Firebase Phone Authentication availability and SMS delivery depend on Firebase configuration and supported regions. This patch does not enable Firebase SMS delivery by itself.
