package com.ofachat.app

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.i18n.phonenumbers.PhoneNumberUtil
import java.util.Locale

/**
 * Global country / calling-code data.
 * Country names are displayed in the currently selected device/app locale.
 */
data class OfaCountry(
    val iso2: String,
    val callingCode: String,
    val name: String
) {
    val dialLabel: String get() = "$name ($callingCode)"
}

object OfaGlobalSupport {
    private val phoneUtil: PhoneNumberUtil by lazy {
        PhoneNumberUtil.getInstance()
    }

    fun countries(displayLocale: Locale = Locale.getDefault()): List<OfaCountry> {
        return Locale.getISOCountries().mapNotNull { iso ->
            val region = iso.uppercase(Locale.ROOT)
            val callingCode = phoneUtil.getCountryCodeForRegion(region)
            if (callingCode <= 0) return@mapNotNull null
            val countryName = Locale("", region).getDisplayCountry(displayLocale)
                .ifBlank { region }
            OfaCountry(region, "+$callingCode", countryName)
        }.distinctBy { it.iso2 }
            .sortedBy { it.name.lowercase(displayLocale) }
    }

    /** Native language names for a language picker. */
    fun languages(): List<Locale> =
        Locale.getAvailableLocales()
            .filter { it.language.isNotBlank() && it.country.isBlank() }
            .distinctBy { it.language }
            .sortedBy { it.getDisplayLanguage(it) }

    /**
     * Apply a selected language to this Activity.
     * Call from a user action, then recreate the Activity to refresh Compose UI.
     * App strings still need translations in res/values-xx/strings.xml.
     */
    fun applyLanguage(activity: Activity, languageTag: String) {
        val locale = Locale.forLanguageTag(languageTag)
        Locale.setDefault(locale)
        val config = Configuration(activity.resources.configuration)
        config.setLocale(locale)
        activity.resources.updateConfiguration(config, activity.resources.displayMetrics)
        activity.recreate()
    }
}

/** Reusable country selector. Pass selectedCountry to your phone-number input. */
@Composable
fun OfaCountryPicker(
    selectedCountry: OfaCountry,
    onCountrySelected: (OfaCountry) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val items = remember { OfaGlobalSupport.countries() }

    androidx.compose.foundation.layout.Box(modifier = modifier) {
        OutlinedTextField(
            value = selectedCountry.dialLabel,
            onValueChange = {},
            readOnly = true,
            label = { Text("Country / Calling code") },
            modifier = Modifier.fillMaxWidth().clickable { expanded = true }
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            items.forEach { country ->
                DropdownMenuItem(
                    text = { Text(country.dialLabel) },
                    onClick = {
                        onCountrySelected(country)
                        expanded = false
                    }
                )
            }
        }
    }
}

/** Default country based on the device SIM/network locale; falls back to Egypt. */
fun defaultOfaCountry(): OfaCountry {
    val region = Locale.getDefault().country.ifBlank { "EG" }
    return OfaGlobalSupport.countries().firstOrNull { it.iso2 == region }
        ?: OfaGlobalSupport.countries().first { it.iso2 == "EG" }
}
