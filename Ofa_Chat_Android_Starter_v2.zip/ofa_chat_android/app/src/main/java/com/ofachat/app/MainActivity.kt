package com.ofachat.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF0B1016)
private val Panel = Color(0xFF151E28)
private val Accent = Color(0xFF45D6A4)
private val Muted = Color(0xFF9AA8B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OfaChatApp() }
    }
}

@Composable
private fun OfaChatApp() {
    val context = LocalContext.current
    val activity = context as Activity
    val auth = remember { FirebaseAuth.getInstance() }

    var phone by remember { mutableStateOf("+20") }
    var code by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("أدخل رقم هاتفك للبدء") }
    var busy by remember { mutableStateOf(false) }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }

    val callbacks = remember {
        object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                busy = true
                auth.signInWithCredential(credential)
                    .addOnCompleteListener { task ->
                        busy = false
                        if (task.isSuccessful) {
                            signedIn = true
                            message = "تم التحقق بنجاح"
                        } else {
                            message = task.exception?.localizedMessage ?: "تعذر تسجيل الدخول"
                        }
                    }
            }

            override fun onVerificationFailed(e: FirebaseException) {
                busy = false
                message = e.localizedMessage ?: "فشل إرسال رمز التحقق"
            }

            override fun onCodeSent(
                id: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                busy = false
                verificationId = id
                message = "تم إرسال الرمز. أدخله هنا."
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Accent,
            onPrimary = Bg,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            if (signedIn) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("𝕺𝖋𝖆 𝖈𝖍𝖆𝖙", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent)
                    Spacer(Modifier.height(12.dp))
                    Text("تم تسجيل الدخول بنجاح", color = Color.White, fontSize = 18.sp)
                    Text("الخطوة التالية: إعداد الملف الشخصي والمحادثات.", color = Muted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                    OutlinedButton(onClick = {
                        auth.signOut()
                        signedIn = false
                        verificationId = null
                        code = ""
                        message = "أدخل رقم هاتفك للبدء"
                    }) { Text("تسجيل الخروج") }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("𝕺𝖋𝖆 𝖈𝖍𝖆𝖙", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("رسائلك، عالمك الخاص.", color = Muted, fontSize = 15.sp)
                    Spacer(Modifier.height(32.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(Modifier.padding(20.dp)) {
                            Text(if (verificationId == null) "تسجيل برقم الهاتف" else "تأكيد رقم الهاتف",
                                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(message, color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))

                            if (verificationId == null) {
                                OutlinedTextField(
                                    value = phone,
                                    onValueChange = { phone = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("رقم الهاتف مع مفتاح الدولة") },
                                    placeholder = { Text("+201XXXXXXXXX") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                )
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        val normalized = phone.trim().replace(" ", "")
                                        if (!normalized.startsWith("+") || normalized.length < 8) {
                                            message = "اكتب الرقم بصيغة دولية، مثل +201XXXXXXXXX"
                                        } else {
                                            busy = true
                                            message = "جارٍ إرسال رمز التحقق..."
                                            val options = PhoneAuthOptions.newBuilder(auth)
                                                .setPhoneNumber(normalized)
                                                .setTimeout(60L, TimeUnit.SECONDS)
                                                .setActivity(activity)
                                                .setCallbacks(callbacks)
                                                .build()
                                            PhoneAuthProvider.verifyPhoneNumber(options)
                                        }
                                    },
                                    enabled = !busy,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (busy) "جارٍ الإرسال..." else "إرسال رمز SMS") }
                            } else {
                                OutlinedTextField(
                                    value = code,
                                    onValueChange = { code = it.filter(Char::isDigit).take(6) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("رمز التحقق المكوّن من 6 أرقام") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    visualTransformation = PasswordVisualTransformation()
                                )
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        val id = verificationId
                                        if (id != null && code.length == 6) {
                                            busy = true
                                            message = "جارٍ التحقق..."
                                            val credential = PhoneAuthProvider.getCredential(id, code)
                                            auth.signInWithCredential(credential)
                                                .addOnCompleteListener { task ->
                                                    busy = false
                                                    if (task.isSuccessful) {
                                                        signedIn = true
                                                        message = "تم التحقق بنجاح"
                                                    } else {
                                                        message = task.exception?.localizedMessage ?: "الرمز غير صحيح أو انتهت صلاحيته"
                                                    }
                                                }
                                        } else {
                                            message = "أدخل الرمز المكوّن من 6 أرقام"
                                        }
                                    },
                                    enabled = !busy,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (busy) "جارٍ التحقق..." else "تأكيد الرمز") }
                                TextButton(
                                    onClick = {
                                        verificationId = null
                                        code = ""
                                        message = "أدخل رقم الهاتف مرة أخرى"
                                    },
                                    modifier = Modifier.align(Alignment.CenterHorizontally)
                                ) { Text("تغيير رقم الهاتف", color = Accent) }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "باستمرارك، ستتلقى رسالة SMS للتحقق من ملكية الرقم. قد تُطبق رسوم شركة الاتصالات.",
                        color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
