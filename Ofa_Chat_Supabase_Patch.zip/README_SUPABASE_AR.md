# Ofa Chat – نقل تسجيل الدخول إلى Supabase (مرحلة 1)

هذه الحزمة مبنية على ملفات Ofa Chat Starter v2 التي كانت في المشروع. وهي تستبدل شاشة Firebase Phone Auth بطلبات Supabase Auth REST لإرسال OTP والتحقق منه.

## ما الذي تم تغييره؟
- إزالة Firebase Authentication وGoogle Services Gradle plugin من البناء.
- إضافة حقلي إعداد عامين: `SUPABASE_URL` و`SUPABASE_PUBLISHABLE_KEY`.
- شاشة إرسال رمز SMS والتحقق منه عبر `/auth/v1/otp` و`/auth/v1/verify`.
- لا يوجد مفتاح `service_role` داخل التطبيق، ولا تضعه في GitHub أو التطبيق مطلقاً.

## مهم قبل تجربة SMS الحقيقي
1. أنشئ مشروع Supabase.
2. من إعدادات المشروع انسخ Project URL وPublishable key فقط.
3. في Supabase Dashboard افتح Authentication > Providers > Phone وفعّل Phone.
4. اربط مزود SMS مدعوماً (مثل Twilio أو MessageBird أو Vonage) وأدخل بياناته داخل لوحة Supabase فقط. إرسال SMS الحقيقي ليس مجانياً بالضرورة.
5. اختبر أولاً باستخدام أرقام الاختبار ورموز OTP الثابتة التي يتيحها Supabase، إن كانت متاحة في إعدادات المشروع.

## وضع بيانات المشروع للبناء
في جذر المشروع أضف إلى `gradle.properties` السطرين التاليين، مع استبدال القيم:

```properties
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

الرابط ومفتاح Publishable مخصصان للاستخدام من تطبيق العميل، لكن صلاحيات قاعدة البيانات يجب أن تُحمى دائماً بـ RLS. لا تستخدم `service_role` في التطبيق.

## ملاحظات هذه المرحلة
- هذه المرحلة تنقل تسجيل الدخول بالهاتف فقط. لا تزال المحادثات والملفات والإشعارات وقواعد البيانات غير منقولة.
- بعد نجاح التحقق، تعرض الواجهة حالة نجاح داخل الجلسة الحالية؛ حفظ/تجديد الجلسة بشكل دائم هو خطوة لاحقة قبل الاعتماد على تسجيل الدخول في الإنتاج.
- لا تحذف مشروع Firebase القديم قبل التأكد من اكتمال النقل واختبار التطبيق.
