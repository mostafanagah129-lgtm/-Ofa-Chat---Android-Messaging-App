package com.ofachat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF0B1016)
private val Panel = Color(0xFF151E28)
private val Accent = Color(0xFF45D6A4)
private val Muted = Color(0xFF9AA8B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OfaChatApp() }
    }
}

@Composable
private fun OfaChatApp() {
    val scope = rememberCoroutineScope()
    var phone by remember { mutableStateOf("+20") }
    var code by remember { mutableStateOf("") }
    var waitingForCode by remember { mutableStateOf(false) }
    var signedIn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("أدخل رقم هاتفك للبدء") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onPrimary = Bg, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (signedIn) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("𝕺𝖋𝖆 𝖈𝖍𝖆𝖙", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent)
                    Spacer(Modifier.height(12.dp))
                    Text("تم التحقق من رقم الهاتف بنجاح", color = Color.White, fontSize = 18.sp)
                    Text("تم ربط تسجيل الدخول بـ Supabase. الخطوة التالية هي حفظ الجلسة وإعداد المحادثات.", color = Muted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                    OutlinedButton(onClick = {
                        signedIn = false
                        waitingForCode = false
                        code = ""
                        phone = "+20"
                        status = "أدخل رقم هاتفك للبدء"
                    }) { Text("تسجيل الخروج") }
                }
            } else {
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("𝕺𝖋𝖆 𝖈𝖍𝖆𝖙", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("رسائلك، عالمك الخاص.", color = Muted, fontSize = 15.sp)
                    Spacer(Modifier.height(32.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                        Column(Modifier.padding(20.dp)) {
                            Text(if (waitingForCode) "تأكيد رقم الهاتف" else "تسجيل برقم الهاتف", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(status, color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))

                            if (!waitingForCode) {
                                OutlinedTextField(
                                    value = phone,
                                    onValueChange = { phone = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("رقم الهاتف مع مفتاح الدولة") },
                                    placeholder = { Text("+201XXXXXXXXX") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                )
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    enabled = !busy,
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = {
                                        val normalized = phone.trim().replace(" ", "").replace("-", "")
                                        if (!normalized.startsWith("+") || normalized.length !in 8..16) {
                                            status = "اكتب الرقم بالصيغة الدولية، مثل +201XXXXXXXXX"
                                        } else if (!isSupabaseConfigured()) {
                                            status = "إعداد Supabase غير مكتمل. أضف رابط المشروع ومفتاح Publishable Key أولاً."
                                        } else {
                                            busy = true
                                            status = "جارٍ طلب رمز التحقق..."
                                            scope.launch {
                                                val result = withContext(Dispatchers.IO) { requestPhoneOtp(normalized) }
                                                busy = false
                                                if (result == null) {
                                                    waitingForCode = true
                                                    status = "إذا كانت إعدادات SMS صحيحة، ستصلك رسالة بالرمز."
                                                } else status = result
                                            }
                                        }
                                    }
                                ) { Text(if (busy) "جارٍ الإرسال..." else "إرسال رمز SMS") }
                            } else {
                                OutlinedTextField(
                                    value = code,
                                    onValueChange = { code = it.filter(Char::isDigit).take(6) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("رمز التحقق المكوّن من 6 أرقام") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    visualTransformation = PasswordVisualTransformation()
                                )
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    enabled = !busy,
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = {
                                        if (code.length != 6) {
                                            status = "أدخل الرمز المكوّن من 6 أرقام"
                                        } else {
                                            busy = true
                                            status = "جارٍ التحقق..."
                                            scope.launch {
                                                val result = withContext(Dispatchers.IO) { verifyPhoneOtp(phone.trim().replace(" ", "").replace("-", ""), code) }
                                                busy = false
                                                if (result == null) {
                                                    signedIn = true
                                                    status = "تم التحقق بنجاح"
                                                } else status = result
                                            }
                                        }
                                    }
                                ) { Text(if (busy) "جارٍ التحقق..." else "تأكيد الرمز") }
                                TextButton(
                                    onClick = { waitingForCode = false; code = ""; status = "أدخل رقم الهاتف مرة أخرى" },
                                    modifier = Modifier.align(Alignment.CenterHorizontally)
                                ) { Text("تغيير رقم الهاتف", color = Accent) }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "إرسال الرسائل يعتمد على تفعيل مزود SMS في إعدادات Supabase، وقد تُطبق رسوم من مزود الرسائل.",
                        color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

private fun isSupabaseConfigured(): Boolean =
    BuildConfig.SUPABASE_URL.startsWith("https://") &&
        !BuildConfig.SUPABASE_URL.contains("YOUR_PROJECT") &&
        BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank() &&
        !BuildConfig.SUPABASE_PUBLISHABLE_KEY.startsWith("YOUR_")

/** Returns null on success, otherwise a safe error message for the UI. */
private fun requestPhoneOtp(phone: String): String? =
    supabaseAuthRequest("/auth/v1/otp", JSONObject().put("phone", phone).put("create_user", true))

/** Returns null on success, otherwise a safe error message for the UI. */
private fun verifyPhoneOtp(phone: String, token: String): String? {
    val body = JSONObject().put("phone", phone).put("token", token).put("type", "sms")
    return supabaseAuthRequest("/auth/v1/verify", body)
}

private fun supabaseAuthRequest(path: String, body: JSONObject): String? {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(BuildConfig.SUPABASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val statusCode = connection.responseCode
        val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (statusCode in 200..299) null else {
            val detail = runCatching { JSONObject(responseText).optString("msg").ifBlank { JSONObject(responseText).optString("message") } }.getOrNull()
            detail?.takeIf { it.isNotBlank() } ?: "تعذر إكمال الطلب (HTTP $statusCode). راجع إعدادات Supabase ومزود SMS."
        }
    } catch (e: Exception) {
        "تعذر الاتصال بـ Supabase. تحقق من الإنترنت ورابط المشروع."
    } finally {
        connection?.disconnect()
    }
}
